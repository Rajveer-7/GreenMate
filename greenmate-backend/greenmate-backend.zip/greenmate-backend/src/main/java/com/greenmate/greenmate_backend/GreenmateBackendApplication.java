package com.greenmate.greenmate_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenmateBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenmateBackendApplication.class, args);
	}

}
