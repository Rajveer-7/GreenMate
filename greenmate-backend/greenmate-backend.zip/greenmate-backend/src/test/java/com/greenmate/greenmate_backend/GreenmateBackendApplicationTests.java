package com.greenmate.greenmate_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenmateBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
